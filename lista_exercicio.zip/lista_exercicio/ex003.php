<!--3. Operações Matemáticas-->

<?php
    $first_value = readline( prompt: "Digite o primeiro valor: ");
    $second_value = readline( prompt: "Digite o segundo valor: ");

    $soma = $first_value + $second_value;

    echo "A soma dos $first_value e $second_value foi $soma";
?>