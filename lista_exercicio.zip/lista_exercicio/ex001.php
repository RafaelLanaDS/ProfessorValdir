<!--1. Saída de Texto (echo e print)-->

<?php
    echo "Rafael Lana de Sousa <br>";
    print "Tenho 23 anos <br>";
    echo "Moro na cidade de Marília";
    print ""
?>

