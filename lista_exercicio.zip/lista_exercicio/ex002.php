<!--2. Variáveis e Concatenação-->

<?php
    $nome = "Rafael Lana";
    $profissao = "Programador";
    $hobby = "Jogar ARK, Tocar violino, Jogar bola";
    echo "Meu nome é .$nome, minha futura profissao vai ser .$profissao, e meus Hobbys são .$hobby ";
?>